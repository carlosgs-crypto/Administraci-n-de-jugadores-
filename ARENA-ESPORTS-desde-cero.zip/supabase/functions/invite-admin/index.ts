// Supabase Edge Function: invita por correo y asigna rol admin.
// Desplegar con: supabase functions deploy invite-admin
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
Deno.serve(async (req) => {
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 })
  const url = Deno.env.get('SUPABASE_URL')!
  const anon = Deno.env.get('SUPABASE_ANON_KEY')!
  const service = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  const authHeader = req.headers.get('Authorization') || ''
  const userClient = createClient(url, anon, { global: { headers: { Authorization: authHeader } } })
  const { data: { user }, error: authError } = await userClient.auth.getUser()
  if (authError || !user) return Response.json({ error: 'No autorizado' }, { status: 401 })
  const adminClient = createClient(url, service)
  const { data: caller } = await adminClient.from('profiles').select('role').eq('id', user.id).single()
  if (caller?.role !== 'owner') return Response.json({ error: 'Solo el propietario puede invitar administradores' }, { status: 403 })
  const body = await req.json()
  const email = String(body.email || '').trim().toLowerCase()
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return Response.json({ error: 'Correo no válido' }, { status: 400 })
  const { data, error } = await adminClient.auth.admin.inviteUserByEmail(email)
  if (error) return Response.json({ error: error.message }, { status: 400 })
  const { error: roleError } = await adminClient.from('profiles').upsert({ id: data.user.id, email, role: 'admin' })
  if (roleError) return Response.json({ error: roleError.message }, { status: 500 })
  return Response.json({ message: `Invitación enviada a ${email}.`, userId: data.user.id })
})