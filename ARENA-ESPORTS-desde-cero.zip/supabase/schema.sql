-- ARENA E-SPORTS: ejecutar completo en Supabase > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  role text not null default 'user' check (role in ('owner','admin','user')),
  created_at timestamptz not null default now()
);

create table if not exists public.players (
  id uuid primary key default gen_random_uuid(),
  nickname text not null,
  player_id text not null,
  age integer check (age is null or age between 1 and 99),
  role text not null,
  team text,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.players enable row level security;

-- Crear perfil automáticamente al registrarse.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id,email,role)
  values(new.id,new.email,'user')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_staff()
returns boolean language sql stable security definer set search_path = public
as $$
  select exists(select 1 from public.profiles where id=auth.uid() and role in ('owner','admin'));
$$;

create or replace function public.is_owner()
returns boolean language sql stable security definer set search_path = public
as $$
  select exists(select 1 from public.profiles where id=auth.uid() and role='owner');
$$;

drop policy if exists "profiles read own or owner" on public.profiles;
create policy "profiles read own or owner" on public.profiles
for select to authenticated using (id=auth.uid() or public.is_owner());

drop policy if exists "owner updates roles" on public.profiles;
create policy "owner updates roles" on public.profiles
for update to authenticated using (public.is_owner()) with check (role in ('admin','user'));

drop policy if exists "signed in read players" on public.players;
create policy "signed in read players" on public.players
for select to authenticated using (true);

drop policy if exists "staff insert players" on public.players;
create policy "staff insert players" on public.players
for insert to authenticated with check (public.is_staff());

drop policy if exists "staff update players" on public.players;
create policy "staff update players" on public.players
for update to authenticated using (public.is_staff()) with check (public.is_staff());

drop policy if exists "staff delete players" on public.players;
create policy "staff delete players" on public.players
for delete to authenticated using (public.is_staff());

-- IMPORTANTE: después de crear tu cuenta, reemplaza TU_CORREO con tu correo real
-- y ejecuta esta sentencia UNA SOLA VEZ desde SQL Editor:
-- update public.profiles set role='owner' where email='TU_CORREO';
